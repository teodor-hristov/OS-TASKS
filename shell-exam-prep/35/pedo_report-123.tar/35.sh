#!/bin/bash

[ $# -eq 1 ] || exit 1
DIR=$1
SAVE="pimp.tmp"
find ./ -type f | grep -E "^[^_]*_report-[0-9]+.tgz$" |
